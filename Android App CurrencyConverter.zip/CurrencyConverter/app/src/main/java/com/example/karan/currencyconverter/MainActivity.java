package com.example.karan.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edt1,edt2;
    Spinner spin1,spin2;
    String curr1,curr2;
    double num,result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt1 =findViewById(R.id.edt1);
        edt2 =findViewById(R.id.edt2);

        spin1 = findViewById(R.id.spin1);
        spin2 = findViewById(R.id.spin2);

        spin1.setSelection(0);
        spin2.setSelection(1);


        spinnerListener();

        addTextWatcher();



    }

    public  void spinnerListener()
    {
        spin1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                calculate();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                calculate();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }


    public void addTextWatcher()
    {
        edt1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                calculate();
            }
        });

    }


    public void calculate()
    {

        curr1 = spin1.getSelectedItem().toString();
        curr2 = spin2.getSelectedItem().toString();

        //Editext1
        if(!edt1.getText().toString().equals("")){

            num = Double.parseDouble(edt1.getText().toString());



            //USD Currency
            if(curr1.equals("USD") && curr2.equals("EUR")){

                result = num * 0.84;

                edt2.setText(String.valueOf(result));

            }

            else if(curr1.equals("USD") && curr2.equals("INR")){

                result = num * 73.46;

                edt2.setText(String.valueOf(result));

            }

            else if(curr1.equals("USD") && curr2.equals("AUD")){

                result = num * 1.37;

                edt2.setText(String.valueOf(result));

            }

            //EUR Currency
            if(curr1.equals("EUR") && curr2.equals("USD")){

                result = num * 1.185;

                edt2.setText(String.valueOf(result));

            }

            else if(curr1.equals("EUR") && curr2.equals("INR")){

                result = num * 87.03;

                edt2.setText(String.valueOf(result));

            }

            else if(curr1.equals("EUR") && curr2.equals("AUD")){

                result = num * 1.63;

                edt2.setText(String.valueOf(result));

            }

            //INR Currency
            if(curr1.equals("INR") && curr2.equals("USD")){

                result = num * 0.014;

                edt2.setText(String.valueOf(result));

            }

            else if(curr1.equals("INR") && curr2.equals("EUR")){

                result = num * 0.011;

                edt2.setText(String.valueOf(result));

            }

            else if(curr1.equals("INR") && curr2.equals("AUD")){

                result = num * 0.019;

                edt2.setText(String.valueOf(result));

            }

            //AUD Currency
            if(curr1.equals("AUD") && curr2.equals("USD")){

                result = num * 0.73;

                edt2.setText(String.valueOf(result));

            }

            else if(curr1.equals("AUD") && curr2.equals("EUR")){

                result = num * 0.61;

                edt2.setText(String.valueOf(result));

            }

            else if(curr1.equals("AUD") && curr2.equals("INR")){

                result = num * 53.49;

                edt2.setText(String.valueOf(result));

            }

            //Both Same Currency
            if(curr1.equals(curr2)) {
                Toast.makeText(this,"Please select different currency!",Toast.LENGTH_LONG).show();
            }
        }
    }


}